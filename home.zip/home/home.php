<!DOCTYPE HTML>
<html>
<head>
<title>Health Care</title>
<link rel="stylesheet" type="text/css" href="home.css">

</head>

<body>

    <header>
    <div class="row">
        <ul class="main-nav">       
        <li class="active"><a href=""> Home</a></li>
        <li><a href="search_by_disease.php"> Search By Disease</a></li>
        <li><a href="search_by_symptoms.php"> Search By Symptoms</a></li>
        <li><a href="add.html"> Add</a></li>
        <li><a href="feedback.html"> Feedback</a></li>
        <li><a href=""> About</a></li>
        <li><a href="login.php"> Login</a></li>
        </ul>  
        
    </div>
    <div class="hero">
        
    </div>
    </header>
    </body>
</html>